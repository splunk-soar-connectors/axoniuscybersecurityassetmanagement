# -*- coding: utf-8 -*-
"""API Library examples.

Use ``script_base.py`` as a starting point for a new API script.
"""
