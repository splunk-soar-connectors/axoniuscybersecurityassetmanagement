============
Installation
============

At the command line, run::

    $ pip install fuzzyfinder

