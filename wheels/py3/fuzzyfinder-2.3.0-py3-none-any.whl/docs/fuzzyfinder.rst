API Reference
=============

.. automodule:: fuzzyfinder
   :members:
   :undoc-members:
   :show-inheritance:
